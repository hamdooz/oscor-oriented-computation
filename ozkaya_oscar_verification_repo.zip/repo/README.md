# Computational Verification of Annihilator-Based Radical Dependency via OSCAR

This repository accompanies the note *"A Computational Verification of
Annihilator-Based Radical Dependency via OSCAR"* (Hamdullah Özkaya), which
verifies, using the [OSCAR](https://www.oscar-system.org) computer algebra
system, the six main theorems of:

> A. Pekin and H. Özkaya, *Annihilator-based dependency relations in
> modules and radical characterizations*, Algebra and Discrete
> Mathematics **41** (2026), no. 2, 235–243.
> https://doi.org/10.12958/adm2471

## Contents

```
note.tex, note.pdf        the full write-up (LaTeX source and compiled PDF)
Project.toml               Julia project file listing OSCAR as a dependency
code/
  00_elementary_examples.jl  Examples 1-3 of the original paper (Z/nZ), pure arithmetic
  01_theorem1.jl             Theorem 1: characterization of radical dependence
  02_theorem2.jl             Theorem 2: total annihilator-dependence
  03_theorem3.jl             Theorem 3: necessity of a singleton Ass(M)
  04_theorem4.jl             Theorem 4: the Radical Distinction Set Z_g(M)
  05_theorem5.jl             Theorem 5: radical sum equivalence (universal statement)
  06_theorem6.jl             Theorem 6: multiplication modules
  run_all.jl                 runs every verification and prints all results
test/
  runtests.jl                formal test suite (Julia Test stdlib, @test assertions)
```

Each file under `code/` defines a `verify_theoremN()` function returning
the booleans discussed in the note, together with an
`if abspath(PROGRAM_FILE) == @__FILE__` guard so the file can also be
run standalone for a human-readable printout.

## Requirements

- Julia 1.10 or newer (developed and tested with Julia 1.12.6).
- [OSCAR.jl](https://github.com/oscar-system/Oscar.jl), itself free
  software licensed under the GPL v3+, combining Singular, GAP,
  Polymake and Antic (scripts `01`–`05` require it; `00` and `06` are
  pure integer arithmetic and have no dependency beyond base Julia).

## Running the test suite

```bash
julia --project=. -e 'using Pkg; Pkg.instantiate()'
julia --project=. test/runtests.jl
```

This runs every verification in the note as a formal `@test` assertion
(via the Julia `Test` standard library) rather than only printing
output for visual inspection; a nonzero exit code indicates a failed
assertion.

## Reproducing the computations by hand

```bash
julia --project=. code/run_all.jl
```

or run any individual script, e.g.:

```bash
julia --project=. code/01_theorem1.jl
```

## Exact package versions used

The computations in the accompanying note were run with Julia 1.12.6 and
the version of `Oscar.jl` available from the General registry in July
2026. Because OSCAR bundles and pins many binary dependencies (GAP,
Singular, Polymake, Antic, and their respective `_jll` artifact
packages), the exact resolved dependency graph is best captured by a
`Manifest.toml` generated at installation time rather than hand-copied
into this README. After running `Pkg.instantiate()` above on a fresh
checkout, running

```bash
julia --project=. -e 'using Pkg; Pkg.status()'
```

will print the locally resolved versions; committing the resulting
`Manifest.toml` to this repository (`git add Manifest.toml`) is
recommended for full computational reproducibility and is left to be
generated on the machine used for the final, camera-ready run, since a
`Manifest.toml` fabricated without an actual OSCAR installation would
not reflect a real, resolvable dependency set.

## Citation

If you use this code, please cite both the original paper above and this
note.
